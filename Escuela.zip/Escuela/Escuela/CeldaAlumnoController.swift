//
//  CeldaAlumnoController.swift
//  Escuela
//
//  Created by Alumno on 10/7/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaAlumnoController : UITableViewCell {
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblCarrera: UILabel!
    @IBOutlet weak var lblMatricula: UILabel!
}
